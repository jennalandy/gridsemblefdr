## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, eval = FALSE------------------------------------------------------
#  # install.packages("devtools")
#  library(devtools)
#  devtools::install_github("jennalandy/gridsemblefdr")
#  
#  library(gridsemblefdr)

## -----------------------------------------------------------------------------
library(gridsemblefdr)

set.seed(123)
test_statistics = c(
  rnorm(900, 0, 3),   # 90% of values near 0
  runif(50, -10, -3), # add 5% negative extreme values
  runif(50, 3, 10)    # add 5% positivive extreme values
)

set.seed(234)
gridsemble_res <- gridsemble(
  test_statistics, 
  verbose = TRUE, 
  parallel = FALSE
)
gridsemble_res$pi0

set.seed(234)
gridsemble_res <- gridsemble(
  test_statistics, 
  verbose = FALSE, 
  parallel = TRUE
)
gridsemble_res$pi0

## ----fig.width = 8------------------------------------------------------------
fdr <- gridsemble_res$fdr
Fdr <- gridsemble_res$Fdr
pi0 <- gridsemble_res$pi0

# compare pi0 predictions between 
# gridsemble and locfdr with default parameters
# true = 0.9
print(pi0)
print(gridsemble_res$default_locfdr$fp0['mlest','p0'])

# compare distributions of fdr between
# gridsemble and locfdr with default parameters
par(mfrow = c(1,2))
hist(fdr, main = 'gridsemble')
hist(gridsemble_res$default_locfdr$fdr, main = 'locfdr - default')

## -----------------------------------------------------------------------------
gridsemble_res <- gridsemble(
  test_statistics, 
  nsim = 5, 
  ensemble_size = 20,
  verbose = FALSE
)
print(gridsemble_res$pi0)

## -----------------------------------------------------------------------------
my_locfdr_grid <- build_locfdr_grid(
  test_statistics,
  pct_range = c(0.001, 0.003),
  pct0_range = c(1/3,1/4),
  nulltype = c(1,2),
  type = c(0),
  method = 'grid'
)

my_fdrtool_grid <- build_fdrtool_grid(
  test_statistics,
  cutoff.method = c('fndr','pct0'),
  pct0_range = c(1/3,1/4),
  method = 'grid'
)

my_qvalue_grid <- build_qvalue_grid(
  test_statistics,
  transf = c('probit','logit'),
  adj_range = c(0.5, 1.5),
  pi0.method = c('bootstrap'),
  smooth.log.pi0 = c('FALSE'),
  method = 'grid'
)

gridsemble_res <- gridsemble(
  test_statistics,
  locfdr_grid = my_locfdr_grid,
  fdrtool_grid = my_fdrtool_grid,
  qvalue_grid = my_qvalue_grid,
  verbose = FALSE
)
print(gridsemble_res$pi0)

## -----------------------------------------------------------------------------
gridsemble_noqvalue_res <- gridsemble(
  test_statistics,
  locfdr_grid = my_locfdr_grid,
  fdrtool_grid = NULL,
  qvalue_grid = my_qvalue_grid,
  verbose = FALSE
)
print(gridsemble_res$pi0)

## -----------------------------------------------------------------------------
gridsemble_res <- gridsemble(
  test_statistics, 
  sim_size = 100,
  verbose = FALSE
)
print(gridsemble_res$pi0)

