## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
library(dplyr)
library(tidyr)
library(ggplot2)
library(gridsemblefdr)

## -----------------------------------------------------------------------------
# get some fake data
set.seed(123)
test_statistics = c(
  rnorm(900, 0, 3),   # 90% of values near 0
  runif(50, -10, -3), # add 5% negative extreme values
  runif(50, 3, 10)    # add 5% positivive extreme values
)
truth = c(
  rep(FALSE, 900),
  rep(TRUE, 100)
)
true_pi0 = 0.9

## -----------------------------------------------------------------------------
# run gridsemble in parallel
set.seed(234)
gridsemble_res <- gridsemble(
  test_statistics, 
  verbose = TRUE, 
  parallel = FALSE
)

## -----------------------------------------------------------------------------
# or run gridsemble not in parallel
set.seed(234)
gridsemble_res <- gridsemble(
  test_statistics, 
  verbose = FALSE, 
  parallel = TRUE
)

## -----------------------------------------------------------------------------
fdr <- gridsemble_res$fdr
Fdr <- gridsemble_res$Fdr
pi0 <- gridsemble_res$pi0

## ----fig.width = 8------------------------------------------------------------
cat(paste0(
  'estimated gridsemble pi0 = ', round(pi0, 4),
  '\ndefault locfdr pi0 = ', round(gridsemble_res$default_locfdr$fp0['mlest','p0'], 4),
  '\ncompared to true pi0 = ', true_pi0
))

## -----------------------------------------------------------------------------
gridsemble_res <- gridsemble(
  test_statistics, 
  nsim = 5, 
  ensemble_size = 20,
  verbose = FALSE
)
cat(paste0(
  'estimated gridsemble pi0 = ', round(gridsemble_res$pi0, 4),
  '\ncompared to true pi0 = ', true_pi0
))

## -----------------------------------------------------------------------------
my_locfdr_grid <- build_locfdr_grid(
  test_statistics,
  pct_range = c(0.001, 0.003),
  pct0_range = c(1/3,1/4),
  nulltype = c(1,2),
  type = c(0),
  method = 'grid'
)

my_fdrtool_grid <- build_fdrtool_grid(
  test_statistics,
  cutoff.method = c('fndr','pct0'),
  pct0_range = c(1/3,1/4),
  method = 'grid'
)

my_qvalue_grid <- build_qvalue_grid(
  test_statistics,
  transf = c('probit','logit'),
  adj_range = c(0.5, 1.5),
  pi0.method = c('bootstrap'),
  smooth.log.pi0 = c('FALSE'),
  method = 'grid'
)

gridsemble_res <- gridsemble(
  test_statistics,
  locfdr_grid = my_locfdr_grid,
  fdrtool_grid = my_fdrtool_grid,
  qvalue_grid = my_qvalue_grid,
  verbose = FALSE
)
cat(paste0(
  'estimated gridsemble pi0 = ', round(gridsemble_res$pi0, 4),
  '\ncompared to true pi0 = ', true_pi0
))

## -----------------------------------------------------------------------------
gridsemble_noqvalue_res <- gridsemble(
  test_statistics,
  locfdr_grid = my_locfdr_grid,
  fdrtool_grid = NULL,
  qvalue_grid = my_qvalue_grid,
  verbose = FALSE
)
cat(paste0(
  'estimated gridsemble pi0 = ', round(gridsemble_noqvalue_res$pi0, 4),
  '\ncompared to true pi0 = ', true_pi0
))

## -----------------------------------------------------------------------------
gridsemble_res <- gridsemble(
  test_statistics, 
  sim_size = 100,
  verbose = FALSE
)
cat(paste0(
  'estimated gridsemble pi0 = ', round(gridsemble_res$pi0, 4),
  '\ncompared to true pi0 = ', true_pi0
))

