library(testthat)
library(gridsemblefdr)

test_check("gridsemblefdr")
