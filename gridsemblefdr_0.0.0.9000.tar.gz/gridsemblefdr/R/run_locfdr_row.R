#' @title Run locfdr
#' @description Run locfdr with a specific set of parameters
#'
#' @param test_statistics vector, test statistics
#' @param locfdr_grid data.frame, each row is a set of hyperparameters
#' @param row integer, row of locfdr_grid
#' @param returnFdr boolean, whether to calculate Fdr form fdr
#'
#' @return
#' \itemize{
#'   \item fdr - estimated local false discovery rates
#'   \item Fdr - estimated left tail-end false discovery rates if returnFdr = TRUE
#'   \item pi0 - estimated proportion of tests that are null
#' }
#'
#' @importFrom locfdr locfdr
#' @importFrom dplyr case_when
run_locfdr_row <- function(
  test_statistics,
  locfdr_grid,
  row,
  returnFdr = TRUE
) {

  # consider pi0 estimation method that matches desired nulltype
  est_method <- dplyr::case_when(
    locfdr_grid[row,'nulltype'] == 0 ~ 'thest',
    locfdr_grid[row,'nulltype'] == 1 ~ 'mlest',
    TRUE ~ 'cmest' # nulltypes 2 and 3 both use central matcing
  )

  tryCatch(
    {
      # try to run locfdr with desired hyperparameters
      res <- locfdr::locfdr(
        test_statistics,
        pct = locfdr_grid$pct[row],
        pct0 = locfdr_grid$pct0[row],
        nulltype = locfdr_grid$nulltype[row],
        type = locfdr_grid$type[row],
        plot = 0
      )

      return(list(
        'fdr' = res$fdr,
        'Fdr' = Fdr_from_fdr(
          fdr = res$fdr,
          test_statistics = test_statistics,
          direction = 'left'
        ),
        'pi0' = res$fp0[est_method,'p0']
      ))
    },
    warning = function(w) {
      if (
        # ignore if one of these three warnings, run again
        grepl('misfit', w) |
        grepl('Discrepancy between central matching', w) |

        # if nulltype = 3 (i.e. using cm) this will be an error
        # as a warning it's just for the pi0 estimation
        grepl('CM estimation failed', w)
      ) {
        res <- suppressWarnings(locfdr::locfdr(
          test_statistics,
          pct = locfdr_grid$pct[row],
          pct0 = locfdr_grid$pct0[row],
          nulltype = locfdr_grid$nulltype[row],
          type = locfdr_grid$type[row],
          plot = 0
        ))

        if (returnFdr) {
          Fdr = Fdr_from_fdr(
            fdr = res$fdr,
            test_statistics = test_statistics,
            direction = 'left'
          )
        } else {
          Fdr = 'not computed'
        }

        return(list(
          'fdr' = res$fdr,
          'Fdr' = Fdr,
          'pi0' = unlist(res$fp0[est_method,'p0'])
        ))
      } else {
        # for other warnings, don't consider this set of hyperparameters
        return(NULL)
      }
    },
    error = function(e) {
      # for errors, don't consider this set of hyperparameters
      return(NULL)
    }
  )
}
